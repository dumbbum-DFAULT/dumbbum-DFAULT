"""
Base File Generator for creating Obsidian .base files from Notion data sources.
"""

import yaml
from typing import Dict, List, Any, Optional


class BaseGenerator:
    """Generates Obsidian .base files from Notion data source schemas."""
    
    def __init__(self):
        """Initialize the base generator."""
        pass
    
    def notion_type_to_base_type(self, notion_type: str, notion_config: Dict[str, Any] = None) -> str:
        """
        Map Notion property type to Obsidian base type.
        
        Args:
            notion_type: Notion property type
            notion_config: Notion property configuration
            
        Returns:
            Obsidian base type
        """
        type_mapping = {
            "title": "string",
            "rich_text": "string",
            "number": "number",
            "select": "string",
            "multi_select": "string[]",
            "status": "string",
            "date": "string",  # ISO date format
            "checkbox": "boolean",
            "url": "string",
            "email": "string",
            "phone_number": "string",
            "people": "string[]",
            "files": "string[]",  # Array of file paths
            "relation": "string[]",  # Array of wikilinks
            "rollup": "any",  # Depends on underlying type
            "formula": "any",  # Depends on formula result type
            "created_time": "string",
            "last_edited_time": "string",
            "created_by": "string",
            "last_edited_by": "string",
            "unique_id": "string"
        }
        
        base_type = type_mapping.get(notion_type, "string")
        
        # Special handling for rollup and formula types
        if notion_type == "rollup" and notion_config:
            # Try to infer type from rollup function
            function = notion_config.get("rollup", {}).get("function", "")
            if function in ["count_all", "count_values", "count_unique_values"]:
                return "number"
            elif function in ["sum", "average", "median", "min", "max", "range"]:
                return "number"
            elif function in ["show_original", "show_unique"]:
                return "string[]"
        
        if notion_type == "formula" and notion_config:
            # Formula type depends on the result, but we'll use 'any' for flexibility
            return "any"
        
        return base_type
    
    def generate_column_config(self, prop_name: str, prop_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate column configuration for a property.
        
        Args:
            prop_name: Property name
            prop_config: Notion property configuration
            
        Returns:
            Column configuration dictionary
        """
        prop_type = prop_config.get("type", "")
        base_type = self.notion_type_to_base_type(prop_type, prop_config)
        
        column_config = {
            "type": base_type,
            "name": prop_name
        }
        
        # Add type-specific configuration
        if prop_type == "select":
            options = prop_config.get("select", {}).get("options", [])
            if options:
                column_config["options"] = [opt.get("name", "") for opt in options]
        
        elif prop_type == "multi_select":
            options = prop_config.get("multi_select", {}).get("options", [])
            if options:
                column_config["options"] = [opt.get("name", "") for opt in options]
        
        elif prop_type == "status":
            status_config = prop_config.get("status", {})
            options = status_config.get("options", [])
            if options:
                column_config["options"] = [opt.get("name", "") for opt in options]
        
        elif prop_type == "number":
            number_config = prop_config.get("number", {})
            format_type = number_config.get("format", "number")
            if format_type != "number":
                column_config["format"] = format_type
        
        elif prop_type == "date":
            column_config["format"] = "date"
        
        elif prop_type == "relation":
            relation_config = prop_config.get("relation", {})
            database_id = relation_config.get("database_id")
            if database_id:
                column_config["relation_database"] = database_id
        
        elif prop_type == "rollup":
            rollup_config = prop_config.get("rollup", {})
            function = rollup_config.get("function", "")
            if function:
                column_config["rollup_function"] = function
            
            relation_prop = rollup_config.get("relation_property_name", "")
            if relation_prop:
                column_config["rollup_relation"] = relation_prop
            
            rollup_prop = rollup_config.get("rollup_property_name", "")
            if rollup_prop:
                column_config["rollup_property"] = rollup_prop
        
        elif prop_type == "formula":
            formula_config = prop_config.get("formula", {})
            expression = formula_config.get("expression", "")
            if expression:
                column_config["formula_expression"] = expression
        
        return column_config
    
    def generate_base_file(self, data_source: Dict[str, Any], database: Dict[str, Any] = None) -> str:
        """
        Generate a .base file content for a data source.
        
        Args:
            data_source: Notion data source object
            database: Parent database object (optional)
            
        Returns:
            YAML content for the .base file
        """
        data_source_id = data_source.get("id", "")
        data_source_title = ""
        
        # Extract title from rich text
        title_rich_text = data_source.get("title", [])
        if title_rich_text and isinstance(title_rich_text, list):
            data_source_title = "".join([rt.get("plain_text", "") for rt in title_rich_text])
        
        # Generate columns configuration
        columns = {}
        properties = data_source.get("properties", {})
        
        for prop_name, prop_config in properties.items():
            column_config = self.generate_column_config(prop_name, prop_config)
            columns[prop_name] = column_config
        
        # Create base file structure
        base_config = {
            "name": data_source_title or "Untitled Data Source",
            "type": "table",
            "columns": columns,
            "views": {
                "Default Table": {
                    "type": "table",
                    "columns": list(columns.keys()),
                    "sort": [],
                    "filter": {},
                    "group": None
                }
            },
            "source": {
                "type": "notion",
                "data_source_id": data_source_id,
                "hints": {
                    "original_title": data_source_title,
                    "created_time": data_source.get("created_time", ""),
                    "last_edited_time": data_source.get("last_edited_time", ""),
                    "parent_database_id": data_source.get("parent", {}).get("database_id", ""),
                    "properties_count": len(properties)
                }
            }
        }
        
        # Add database information if available
        if database:
            database_title = ""
            db_title_rich_text = database.get("title", [])
            if db_title_rich_text and isinstance(db_title_rich_text, list):
                database_title = "".join([rt.get("plain_text", "") for rt in db_title_rich_text])
            
            base_config["source"]["hints"]["parent_database_title"] = database_title
        
        # Convert to YAML
        yaml_content = yaml.dump(base_config, default_flow_style=False, allow_unicode=True, sort_keys=False)
        
        return yaml_content
    
    def generate_base_filename(self, data_source: Dict[str, Any]) -> str:
        """
        Generate a filename for the .base file.
        
        Args:
            data_source: Notion data source object
            
        Returns:
            Filename with .base extension
        """
        # Extract title
        title_rich_text = data_source.get("title", [])
        title = ""
        if title_rich_text and isinstance(title_rich_text, list):
            title = "".join([rt.get("plain_text", "") for rt in title_rich_text])
        
        # Sanitize title for filename
        if not title:
            title = "untitled"
        
        # Simple sanitization
        sanitized = "".join(c for c in title if c.isalnum() or c in " -_").strip()
        sanitized = sanitized.replace(" ", "_").lower()
        
        # Add data source ID for uniqueness
        data_source_id = data_source.get("id", "").replace("-", "")[:8]
        
        return f"{sanitized}_{data_source_id}.base"

