import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'

export function FeatureCard({ icon: Icon, title, description, features, status = "ready" }) {
  const statusColors = {
    ready: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
    beta: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
    coming: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
  }

  const statusLabels = {
    ready: "Ready",
    beta: "Beta",
    coming: "Coming Soon"
  }

  return (
    <Card className="h-full transition-all duration-200 hover:shadow-lg hover:scale-[1.02]">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Icon className="h-6 w-6 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{title}</CardTitle>
            </div>
          </div>
          <Badge className={statusColors[status]}>
            {statusLabels[status]}
          </Badge>
        </div>
        <CardDescription className="text-sm leading-relaxed">
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2 text-sm">
              <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
              <span className="text-muted-foreground">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

