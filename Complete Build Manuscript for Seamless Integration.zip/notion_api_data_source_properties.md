# Notion API Data Source Properties

This document summarizes the key findings regarding Notion API data source properties, focusing on their structure and how they are handled, especially for relations, rollups, and formulas.

## General Property Structure
Every data source property object contains the following keys:
- `id`: An identifier for the property.
- `name`: The name of the property as it appears in Notion.
- `description`: The description of a property.
- `type`: The type that controls the behavior of the property (e.g., `checkbox`, `created_by`, `date`, `email`, `files`, `formula`, `last_edited_by`, `last_edited_time`, `multi_select`, `number`, `people`, `phone_number`, `relation`, `rich_text`, `rollup`, `select`, `status`, `title`, `url`).

Each property type has a corresponding type-specific object with additional configuration.

## Specific Property Types

### Formula
A `formula` data source property is rendered in the Notion UI as a column that contains values derived from a provided expression. The `formula` type object defines the expression in the `expression` field.

Example:
```json
"Updated price": {
  "id": "YU%7C%40",
  "name": "Updated price",
  "type": "formula",
  "formula": {
    "expression": "{{notion:block_property:BtVS:00000000-0000-0000-0000-000000000000:8994905a-074a-415f-9bcf-d1f8b4fa38e4}}/2"
  }
}
```

### Multi-select
A `multi_select` data source property contains values from a range of options. The `multi_select` type object includes an array of `options` objects, each detailing `color`, `id`, and `name`.

### Number
A `number` data source property contains numeric values. The `number` type object contains a `format` field specifying how the number is displayed (e.g., `number`, `percent`, various currencies).

### People
A `people` data source property contains mentions of users. The `people` type object can specify whether to include `person` objects or `bot` objects.

### Relation
A `relation` data source property links pages in one data source to pages in another. The `relation` type object specifies:
- `database_id`: The ID of the database that the relation property refers to.
- `type`: Can be `single_property` or `dual_property`.
- `single_property`: If `type` is `single_property`, this object is empty.
- `dual_property`: If `type` is `dual_property`, this object contains `synced_property_id` and `synced_property_name`.

### Rich text
A `rich_text` data source property contains rich text values. The `rich_text` type object is empty.

### Rollup
A `rollup` data source property displays an aggregated value from a related data source. The `rollup` type object specifies:
- `rollup_property_name`: The name of the property in the related data source to rollup.
- `rollup_property_id`: The ID of the property in the related data source to rollup.
- `relation_property_name`: The name of the relation property connecting the two data sources.
- `relation_property_id`: The ID of the relation property.
- `function`: The aggregation function (e.g., `count_all`, `count_values`, `count_unique_values`, `sum`, `average`, `median`, `min`, `max`, `range`, `show_original`, `show_unique`, `show_original_values`, `show_unique_values`).

### Select
A `select` data source property contains values from a single selection of options. Similar to `multi_select`, it includes an array of `options` objects, each with `color`, `id`, and `name`.

### Status
A `status` data source property represents the status of an item. The `status` type object contains `options` (groups of statuses) and `groups` (categories like `Todo`, `In Progress`, `Done`).

### Title
A `title` data source property is the primary identifier for pages within a data source. The `title` type object is empty.

### URL
A `url` data source property contains URL values. The `url` type object is empty.

### Unique ID
A `unique_id` data source property automatically generates a unique identifier for each page. The `unique_id` type object specifies the `prefix` and `number` format.

