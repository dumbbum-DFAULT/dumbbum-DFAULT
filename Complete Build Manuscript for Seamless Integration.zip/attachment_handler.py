"""
Attachment Handler for downloading and managing Notion file attachments.
"""

import os
import hashlib
import mimetypes
from typing import Dict, List, Any, Tuple
from urllib.parse import urlparse
import requests


class AttachmentHandler:
    """Handles downloading and organizing Notion file attachments."""
    
    def __init__(self, output_dir: str):
        """
        Initialize the attachment handler.
        
        Args:
            output_dir: Base output directory for the import
        """
        self.output_dir = output_dir
        self.attachments_dir = os.path.join(output_dir, "attachments")
        self.downloaded_files = {}  # URL -> local path mapping
        
        # Create attachments directory
        os.makedirs(self.attachments_dir, exist_ok=True)
    
    def get_file_hash(self, content: bytes) -> str:
        """
        Generate a hash for file content.
        
        Args:
            content: File content as bytes
            
        Returns:
            SHA256 hash of the content
        """
        return hashlib.sha256(content).hexdigest()
    
    def get_file_extension(self, url: str, content_type: str = None) -> str:
        """
        Determine file extension from URL or content type.
        
        Args:
            url: File URL
            content_type: HTTP Content-Type header
            
        Returns:
            File extension (including dot)
        """
        # Try to get extension from URL
        parsed_url = urlparse(url)
        path = parsed_url.path
        if path and '.' in path:
            return os.path.splitext(path)[1].lower()
        
        # Try to get extension from content type
        if content_type:
            extension = mimetypes.guess_extension(content_type)
            if extension:
                return extension.lower()
        
        # Default to .bin if unknown
        return ".bin"
    
    def download_file(self, url: str, filename_hint: str = None) -> Tuple[str, bool]:
        """
        Download a file from URL and save it locally.
        
        Args:
            url: File URL
            filename_hint: Suggested filename (optional)
            
        Returns:
            Tuple of (local_path, is_image)
        """
        # Check if already downloaded
        if url in self.downloaded_files:
            return self.downloaded_files[url]
        
        try:
            # Download the file
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            content = response.content
            content_type = response.headers.get('Content-Type', '')
            
            # Generate hash and extension
            file_hash = self.get_file_hash(content)
            extension = self.get_file_extension(url, content_type)
            
            # Create filename
            filename = f"{file_hash}{extension}"
            local_path = os.path.join(self.attachments_dir, filename)
            
            # Save file
            with open(local_path, 'wb') as f:
                f.write(content)
            
            # Determine if it's an image
            is_image = content_type.startswith('image/') or extension.lower() in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg']
            
            # Store relative path for markdown
            relative_path = os.path.join("attachments", filename)
            result = (relative_path, is_image)
            
            self.downloaded_files[url] = result
            return result
            
        except Exception as e:
            print(f"Failed to download {url}: {str(e)}")
            # Return original URL as fallback
            return (url, False)
    
    def process_file_property(self, files_list: List[Dict[str, Any]]) -> List[str]:
        """
        Process a files property and download all files.
        
        Args:
            files_list: List of file objects from Notion
            
        Returns:
            List of local file paths
        """
        local_paths = []
        
        for file_obj in files_list:
            if not isinstance(file_obj, dict):
                continue
            
            # Get file URL
            file_info = file_obj.get("file") or file_obj.get("external")
            if not file_info:
                continue
            
            url = file_info.get("url")
            if not url:
                continue
            
            # Get filename hint
            filename_hint = file_obj.get("name", "")
            
            # Download file
            local_path, is_image = self.download_file(url, filename_hint)
            local_paths.append(local_path)
        
        return local_paths
    
    def process_image_block(self, image_block: Dict[str, Any]) -> str:
        """
        Process an image block and download the image.
        
        Args:
            image_block: Image block from Notion
            
        Returns:
            Local path to the downloaded image
        """
        image_data = image_block.get("image", {})
        file_info = image_data.get("file") or image_data.get("external")
        
        if not file_info:
            return ""
        
        url = file_info.get("url")
        if not url:
            return ""
        
        # Download image
        local_path, is_image = self.download_file(url)
        return local_path
    
    def update_markdown_with_attachments(self, markdown_content: str) -> str:
        """
        Update markdown content to use local attachment paths.
        
        Args:
            markdown_content: Original markdown content
            
        Returns:
            Updated markdown content with local paths
        """
        updated_content = markdown_content
        
        # Replace image URLs with local paths
        for url, (local_path, is_image) in self.downloaded_files.items():
            if is_image:
                # Replace image references
                updated_content = updated_content.replace(f"]({url})", f"]({local_path})")
            else:
                # Replace file links
                updated_content = updated_content.replace(f"]({url})", f"]({local_path})")
        
        return updated_content
    
    def get_attachment_stats(self) -> Dict[str, Any]:
        """
        Get statistics about downloaded attachments.
        
        Returns:
            Dictionary with attachment statistics
        """
        total_files = len(self.downloaded_files)
        image_files = sum(1 for _, (_, is_image) in self.downloaded_files.items() if is_image)
        other_files = total_files - image_files
        
        return {
            "total_files": total_files,
            "image_files": image_files,
            "other_files": other_files,
            "attachments_dir": self.attachments_dir
        }

