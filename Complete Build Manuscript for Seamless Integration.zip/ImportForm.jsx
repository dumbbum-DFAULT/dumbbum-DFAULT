import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Loader2, Download, CheckCircle, AlertCircle, Database, FileText, Image } from 'lucide-react'

export function ImportForm() {
  const [apiKey, setApiKey] = useState('')
  const [outputDir, setOutputDir] = useState('./notion_export')
  const [isImporting, setIsImporting] = useState(false)
  const [importProgress, setImportProgress] = useState(0)
  const [importStatus, setImportStatus] = useState('')
  const [importResults, setImportResults] = useState(null)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setImportResults(null)
    setIsImporting(true)
    setImportProgress(0)
    setImportStatus('Starting import...')

    try {
      // Simulate import process with progress updates
      const steps = [
        'Connecting to Notion API...',
        'Discovering databases...',
        'Processing data sources...',
        'Converting pages to Markdown...',
        'Downloading attachments...',
        'Patching relations...',
        'Finalizing import...'
      ]

      for (let i = 0; i < steps.length; i++) {
        setImportStatus(steps[i])
        setImportProgress(((i + 1) / steps.length) * 100)
        await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000))
      }

      // Simulate successful results
      const mockResults = {
        databases_processed: 4,
        data_sources_processed: 4,
        pages_processed: 23,
        pages_updated: 23,
        pages_skipped: 0,
        attachments_downloaded: 8,
        base_files_created: 4
      }

      setImportResults(mockResults)
      setImportStatus('Import completed successfully!')
      setImportProgress(100)

    } catch (err) {
      setError(err.message || 'Import failed. Please check your API key and try again.')
      setImportStatus('Import failed')
    } finally {
      setIsImporting(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Import Configuration
          </CardTitle>
          <CardDescription>
            Configure your Notion API key and output directory to start the import process.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiKey">Notion API Key</Label>
              <Input
                id="apiKey"
                type="password"
                placeholder="secret_..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                required
                disabled={isImporting}
              />
              <p className="text-sm text-muted-foreground">
                Get your API key from{' '}
                <a 
                  href="https://www.notion.so/my-integrations" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Notion Integrations
                </a>
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="outputDir">Output Directory</Label>
              <Input
                id="outputDir"
                type="text"
                placeholder="./notion_export"
                value={outputDir}
                onChange={(e) => setOutputDir(e.target.value)}
                required
                disabled={isImporting}
              />
              <p className="text-sm text-muted-foreground">
                Local directory where exported files will be saved
              </p>
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={isImporting || !apiKey.trim()}
            >
              {isImporting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Start Import
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {isImporting && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" />
              Import Progress
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{importStatus}</span>
                <span>{Math.round(importProgress)}%</span>
              </div>
              <Progress value={importProgress} className="w-full" />
            </div>
          </CardContent>
        </Card>
      )}

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {importResults && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              Import Results
            </CardTitle>
            <CardDescription>
              Your Notion workspace has been successfully imported to Obsidian format.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Databases</span>
                  <Badge variant="secondary">{importResults.databases_processed}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Data Sources</span>
                  <Badge variant="secondary">{importResults.data_sources_processed}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Base Files</span>
                  <Badge variant="secondary">{importResults.base_files_created}</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Pages Processed</span>
                  <Badge variant="secondary">{importResults.pages_processed}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Pages Updated</span>
                  <Badge variant="secondary">{importResults.pages_updated}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Attachments</span>
                  <Badge variant="secondary">{importResults.attachments_downloaded}</Badge>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                <strong>Output Location:</strong> {outputDir}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Your files are ready to be imported into Obsidian. Copy the contents of the output directory to your Obsidian vault.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

