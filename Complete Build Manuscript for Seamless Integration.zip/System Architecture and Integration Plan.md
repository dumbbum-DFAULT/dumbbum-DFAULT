# System Architecture and Integration Plan

This document outlines the system architecture and integration plan for the end-to-end Notion importer solution, focusing on seamless integration and adherence to the specified requirements.

## 1. Overall Architecture

The solution will consist of a Python-based importer application that interacts with the Notion API to retrieve database information and page content. This data will then be transformed and stored locally in an Obsidian-flavored Markdown format, including `.base` files for Notion databases. The importer will manage a state file for incremental synchronization.

```mermaid
graph TD
    A[Notion API] --> B{Importer Application}
    B --> C[Local File System (Obsidian-flavored Markdown)]
    B --> D[State File (.obsidian/notion-import.json)]
    C --> E[Attachments Folder (attachments/<hash>.<ext>)]
```

## 2. Data Flow

The data flow will follow these steps:

1.  **Initialization/Configuration**: The importer will read configuration, including Notion API key and target local directory. It will also load the `notion-import.json` state file if it exists.
2.  **Notion API Interaction**: The importer will use the Notion API (version `2025-09-03`) to:
    *   Retrieve a list of databases and their associated data sources.
    *   For each data source, retrieve its schema (properties).
    *   Query pages (items) within each data source, handling pagination (100 items per page) and implementing backoff on `429` (rate limit) errors.
3.  **Data Transformation**: Retrieved Notion data will be transformed into Obsidian-flavored Markdown. This includes:
    *   Converting Notion blocks (headings, lists, callouts, code, tables) to Markdown.
    *   Mapping Notion properties to frontmatter in Markdown files, adhering to the specified column mapping rules.
    *   Materializing formulas and rollups as snapshot values.
4.  **Attachment Handling**: Files attached to Notion pages will be downloaded and stored in a local `attachments/` folder. Images will be embedded in Markdown, while other files will be linked.
5.  **Relation Resolution**: Relations will be handled in two phases:
    *   Initially, write `[]` placeholders for relations.
    *   In a second pass, patch these placeholders with wikilinks (`[[Title]]`) to the corresponding local Markdown files.
6.  **File Naming and Storage**: Markdown files will be named deterministically using `sanitize(title) + '—' + pageId.slice(0,8) + '.md'`. A redirect note will be stored if a filename changes due to a title edit.
7.  **Incremental Sync**: The `notion-import.json` state file will track the last sync status. The importer will skip unchanged pages and update only modified ones.
8.  **`.base` File Generation**: For each data source, a `.base` file will be generated with a Default Table view, including `source.hints` for view metadata.

## 3. Key Components and Implementation Details

### 3.1. Notion API Client
*   Utilize the `notion-client` Python library or a custom HTTP client to interact with the Notion API.
*   Ensure API version `2025-09-03` is specified in requests.
*   Implement error handling for rate limits (`429`) with exponential backoff.

### 3.2. Data Fetching Logic
*   Iterate through databases and their data sources.
*   Implement pagination for querying pages to retrieve all entries.
*   Store raw Notion JSON responses for golden tests and debugging.

### 3.3. Markdown Conversion Module
*   **Block Renderer**: A component responsible for converting Notion rich text blocks (paragraphs, headings, lists, callouts, code blocks, tables) into Obsidian-flavored Markdown syntax.
*   **Property Mapper**: A function to map Notion property types to Markdown frontmatter, following the specified rules:
    *   `title` → `string` (frontmatter also stores original title if non-ASCII)
    *   `rich_text` → `string` (markdown escaping outside code, preserve underline with `<u>`)
    *   `number` → number
    *   `select` → string (name)
    *   `multi_select` → `string[]` (names)
    *   `status` → string (name)
    *   `date` → ISO: `YYYY-MM-DD` or `YYYY-MM-DDTHH:mm:ssZ`, with `timezone` if present
    *   `checkbox` → boolean
    *   `url/email/phone` → string
    *   `people` → `string[]` (names or emails; prefer names)
    *   `files` → local paths (array), image blocks → embedded, other files → links
    *   `relation` → `string[]` (wikilinks; placeholders first, patched later)
    *   `rollup` → snapshot by underlying type (number/string/date/array length)
    *   `formula` → snapshot by output type; include `formula_expression` in `notion:` subtree for provenance

### 3.4. Attachment Downloader and Relinker
*   A module to download files referenced in Notion `files` properties.
*   Store downloaded files in `attachments/<hash>.<ext>`.
*   Modify Markdown content to embed images and link other files using local paths.

### 3.5. Relation Patcher
*   After initial Markdown generation, a second pass will resolve relation placeholders to actual Obsidian wikilinks.

### 3.6. Incremental Sync Manager
*   A JSON file (`.obsidian/notion-import.json`) will store the last sync timestamp and a mapping of Notion page IDs to local file paths and their last modified times.
*   Before processing a page, compare its `last_edited_time` with the stored value to determine if an update is needed.
*   Handle renames by storing a `redirect` note if the filename changes.

### 3.7. `.base` File Generator
*   For each data source, generate a YAML file (`.base`) that represents the data source schema.
*   Include a `Default Table` view and `source.hints` with view metadata.

### 3.8. Testing and Validation
*   Implement golden tests for block rendering, property mapping, relations, attachments, and base schema.
*   Create a sample Notion workspace fixture (JSON) and snapshot outputs for deterministic testing.

## 4. Development Workflow

1.  **Vertical Slice Implementation**: Focus on getting a single, small Notion workspace (e.g., the 4 databases described in the requirements) to sync end-to-end.
2.  **Iterative Development**: Implement each component (API client, Markdown converter, attachment handler, relation patcher, incremental sync, `.base` generator) incrementally.
3.  **Testing**: Continuously run golden tests to ensure correctness and prevent regressions.
4.  **Refinement**: Optimize for performance, error handling, and user experience.

This plan provides a clear roadmap for building a robust and seamless Notion integration solution.

