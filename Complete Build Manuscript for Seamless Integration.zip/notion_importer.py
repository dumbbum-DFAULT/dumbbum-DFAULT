"""
Main Notion Importer module that orchestrates the entire import process.
"""

import os
import sys
from typing import Dict, List, Any, Optional
from dotenv import load_dotenv

from notion_client import NotionClient
from markdown_converter import MarkdownConverter
from attachment_handler import AttachmentHandler
from base_generator import BaseGenerator
from sync_manager import SyncManager
from relation_patcher import RelationPatcher


class NotionImporter:
    """Main importer class that orchestrates the entire import process."""
    
    def __init__(self, api_key: str, output_dir: str):
        """
        Initialize the Notion importer.
        
        Args:
            api_key: Notion API key
            output_dir: Output directory for imported files
        """
        self.api_key = api_key
        self.output_dir = output_dir
        
        # Initialize components
        self.client = NotionClient(api_key)
        self.markdown_converter = MarkdownConverter()
        self.attachment_handler = AttachmentHandler(output_dir)
        self.base_generator = BaseGenerator()
        self.sync_manager = SyncManager(output_dir)
        self.relation_patcher = RelationPatcher(output_dir)
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Statistics
        self.stats = {
            "databases_processed": 0,
            "data_sources_processed": 0,
            "pages_processed": 0,
            "pages_updated": 0,
            "pages_skipped": 0,
            "attachments_downloaded": 0,
            "base_files_created": 0
        }
    
    def import_all(self) -> Dict[str, Any]:
        """
        Import all accessible databases and their content.
        
        Returns:
            Import statistics
        """
        print("Starting Notion import...")
        
        try:
            # Step 1: Discover databases
            print("Discovering databases...")
            databases = self.client.search_databases()
            print(f"Found {len(databases)} databases")
            
            # Step 2: Process each database
            all_data_sources = []
            for database in databases:
                database_id = database.get("id", "")
                print(f"Processing database: {database_id}")
                
                # Get full database details
                full_database = self.client.get_database(database_id)
                
                # Update database state
                self.sync_manager.update_database_state(
                    database_id,
                    full_database.get("last_edited_time", ""),
                    self.extract_title(full_database.get("title", []))
                )
                
                # Find data sources for this database
                data_sources = self.discover_data_sources(database_id)
                all_data_sources.extend(data_sources)
                
                self.stats["databases_processed"] += 1
            
            # Step 3: Process data sources and create .base files
            print(f"Processing {len(all_data_sources)} data sources...")
            for data_source in all_data_sources:
                self.process_data_source(data_source)
            
            # Step 4: Patch relations
            print("Patching relations...")
            self.relation_patcher.patch_all_relations(all_data_sources, self.sync_manager)
            
            # Step 5: Mark sync complete
            self.sync_manager.mark_sync_complete()
            
            # Update final statistics
            attachment_stats = self.attachment_handler.get_attachment_stats()
            self.stats["attachments_downloaded"] = attachment_stats["total_files"]
            
            print("Import completed successfully!")
            return self.stats
            
        except Exception as e:
            print(f"Import failed: {str(e)}")
            raise
    
    def discover_data_sources(self, database_id: str) -> List[Dict[str, Any]]:
        """
        Discover data sources for a database.
        
        Args:
            database_id: Database ID
            
        Returns:
            List of data source objects
        """
        # For now, we'll assume each database has one data source
        # In the future, this could be enhanced to discover multiple data sources
        try:
            # Try to get the database and infer data source
            database = self.client.get_database(database_id)
            
            # Create a mock data source object based on database properties
            # This is a simplification - in reality, we'd need to query for actual data sources
            data_source = {
                "id": database_id,  # Using database ID as data source ID for now
                "title": database.get("title", []),
                "properties": database.get("properties", {}),
                "created_time": database.get("created_time", ""),
                "last_edited_time": database.get("last_edited_time", ""),
                "parent": {"database_id": database_id}
            }
            
            return [data_source]
            
        except Exception as e:
            print(f"Warning: Could not discover data sources for database {database_id}: {e}")
            return []
    
    def process_data_source(self, data_source: Dict[str, Any]):
        """
        Process a single data source.
        
        Args:
            data_source: Data source object
        """
        data_source_id = data_source.get("id", "")
        data_source_title = self.extract_title(data_source.get("title", []))
        last_edited_time = data_source.get("last_edited_time", "")
        
        print(f"Processing data source: {data_source_title} ({data_source_id})")
        
        # Check if we need to update this data source
        if not self.sync_manager.should_update_data_source(data_source_id, last_edited_time):
            print(f"Skipping data source {data_source_id} (no changes)")
            return
        
        # Create .base file
        base_filename = self.base_generator.generate_base_filename(data_source)
        base_content = self.base_generator.generate_base_file(data_source)
        base_path = os.path.join(self.output_dir, base_filename)
        
        with open(base_path, 'w', encoding='utf-8') as f:
            f.write(base_content)
        
        print(f"Created base file: {base_filename}")
        self.stats["base_files_created"] += 1
        
        # Update data source state
        self.sync_manager.update_data_source_state(
            data_source_id, base_filename, last_edited_time, data_source_title
        )
        
        # Query pages from this data source
        try:
            # For now, we'll use the database query endpoint
            # In the future, this should use the data source query endpoint
            pages = self.client.query_data_source(data_source_id)
            print(f"Found {len(pages)} pages in data source")
            
            # Process each page
            for page in pages:
                self.process_page(page, data_source)
            
        except Exception as e:
            print(f"Warning: Could not query pages from data source {data_source_id}: {e}")
        
        self.stats["data_sources_processed"] += 1
    
    def process_page(self, page: Dict[str, Any], data_source: Dict[str, Any]):
        """
        Process a single page.
        
        Args:
            page: Page object
            data_source: Parent data source object
        """
        page_id = page.get("id", "")
        last_edited_time = page.get("last_edited_time", "")
        
        # Extract title
        title = self.extract_page_title(page, data_source)
        
        # Check if we need to update this page
        if not self.sync_manager.should_update_page(page_id, last_edited_time):
            print(f"Skipping page {title} (no changes)")
            self.stats["pages_skipped"] += 1
            return
        
        print(f"Processing page: {title}")
        
        try:
            # Get page blocks (content)
            blocks = self.client.get_page_blocks(page_id)
            
            # Process attachments in blocks
            self.process_page_attachments(blocks)
            
            # Process file properties
            self.process_file_properties(page, data_source)
            
            # Convert to markdown
            markdown_content = self.markdown_converter.page_to_markdown(page, blocks, data_source)
            
            # Update markdown with local attachment paths
            markdown_content = self.attachment_handler.update_markdown_with_attachments(markdown_content)
            
            # Generate filename
            filename = self.markdown_converter.generate_filename(title, page_id)
            filepath = os.path.join(self.output_dir, filename)
            
            # Write markdown file
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(markdown_content)
            
            # Update page state
            self.sync_manager.update_page_state(page_id, filename, last_edited_time, title)
            
            print(f"Created/updated: {filename}")
            self.stats["pages_updated"] += 1
            
        except Exception as e:
            print(f"Warning: Could not process page {page_id}: {e}")
        
        self.stats["pages_processed"] += 1
    
    def extract_title(self, title_rich_text: List[Dict[str, Any]]) -> str:
        """
        Extract plain text title from rich text.
        
        Args:
            title_rich_text: Rich text array
            
        Returns:
            Plain text title
        """
        if not title_rich_text or not isinstance(title_rich_text, list):
            return "Untitled"
        
        return "".join([rt.get("plain_text", "") for rt in title_rich_text]) or "Untitled"
    
    def extract_page_title(self, page: Dict[str, Any], data_source: Dict[str, Any]) -> str:
        """
        Extract title from a page.
        
        Args:
            page: Page object
            data_source: Data source object
            
        Returns:
            Page title
        """
        properties = page.get("properties", {})
        data_source_properties = data_source.get("properties", {})
        
        # Find the title property
        for prop_name, prop_config in data_source_properties.items():
            if prop_config.get("type") == "title" and prop_name in properties:
                title_value = properties[prop_name].get("title", [])
                return self.extract_title(title_value)
        
        # Fallback to first property that looks like a title
        for prop_name, prop_value in properties.items():
            if isinstance(prop_value, dict) and "title" in prop_value:
                title_value = prop_value.get("title", [])
                return self.extract_title(title_value)
        
        return "Untitled"
    
    def process_page_attachments(self, blocks: List[Dict[str, Any]]):
        """
        Process attachments in page blocks.
        
        Args:
            blocks: List of page blocks
        """
        for block in blocks:
            block_type = block.get("type", "")
            
            if block_type == "image":
                self.attachment_handler.process_image_block(block)
            elif block_type == "file":
                # Handle file blocks if needed
                pass
    
    def process_file_properties(self, page: Dict[str, Any], data_source: Dict[str, Any]):
        """
        Process file properties in a page.
        
        Args:
            page: Page object
            data_source: Data source object
        """
        properties = page.get("properties", {})
        data_source_properties = data_source.get("properties", {})
        
        for prop_name, prop_config in data_source_properties.items():
            if prop_config.get("type") == "files" and prop_name in properties:
                files_value = properties[prop_name].get("files", [])
                if files_value:
                    self.attachment_handler.process_file_property(files_value)


def main():
    """Main entry point for the importer."""
    # Load environment variables
    load_dotenv()
    
    # Get configuration
    api_key = os.getenv("NOTION_API_KEY")
    output_dir = os.getenv("OUTPUT_DIR", "./notion_export")
    
    if not api_key:
        print("Error: NOTION_API_KEY environment variable is required")
        sys.exit(1)
    
    # Create importer and run
    importer = NotionImporter(api_key, output_dir)
    
    try:
        stats = importer.import_all()
        
        print("\n=== Import Statistics ===")
        for key, value in stats.items():
            print(f"{key}: {value}")
        
        print(f"\nFiles exported to: {output_dir}")
        
    except Exception as e:
        print(f"Import failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()

