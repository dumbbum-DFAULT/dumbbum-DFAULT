# Notion to Obsidian Importer

A complete end-to-end solution for importing Notion databases and pages into Obsidian-flavored Markdown format, with seamless integration and incremental synchronization.

## Features

- ✅ Uses Notion API **2025-09-03** with **data sources**
- ✅ Converts pages to **Obsidian-flavored Markdown** (headings, lists, callouts, code, tables)
- ✅ **Attachments** downloaded & embedded/linked in user's attachment folder
- ✅ Databases → **.base** files (columns mapped, Default Table view, `source.hints`)
- ✅ **Relations** resolved to wikilinks (two-phase)
- ✅ **Formulas** materialized; **rollups** snapshot values
- ✅ **Incremental sync** with state file; redirects on rename
- ✅ Deterministic filename generation
- ✅ Comprehensive error handling and rate limiting

## Installation

1. Clone or download this repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Configuration

1. Copy the example environment file:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and add your Notion API key:
   ```
   NOTION_API_KEY=your_notion_api_key_here
   OUTPUT_DIR=./notion_export
   ```

3. To get your Notion API key:
   - Go to [Notion Integrations](https://www.notion.so/my-integrations)
   - Create a new integration
   - Copy the "Internal Integration Token"
   - Share your databases with the integration

## Usage

### Basic Import

Run the importer to sync all accessible databases:

```bash
python notion_importer.py
```

### Output Structure

The importer creates the following structure:

```
notion_export/
├── .obsidian/
│   └── notion-import.json          # Sync state file
├── attachments/                    # Downloaded files
│   ├── abc123.jpg
│   └── def456.pdf
├── projects_12345678.base          # Database schema files
├── tasks_87654321.base
├── my-project—12345678.md          # Page files
├── important-task—87654321.md
└── ...
```

### Column Mapping Rules

The importer maps Notion properties to Obsidian frontmatter:

- `title` → `string` (frontmatter also stores original title if non-ASCII)
- `rich_text` → `string` (markdown escaping outside code, preserve underline with `<u>`)
- `number` → number
- `select` → string (name)
- `multi_select` → string[] (names)
- `status` → string (name)
- `date` → ISO: `YYYY-MM-DD` or `YYYY-MM-DDTHH:mm:ssZ`, with `timezone` if present
- `checkbox` → boolean
- `url/email/phone` → string
- `people` → string[] (names or emails; prefer names)
- `files` → local paths (array), image blocks → embedded, other files → links
- `relation` → string[] (wikilinks; placeholders first, patched later)
- `rollup` → snapshot by underlying type (number/string/date/array length)
- `formula` → snapshot by output type; include `formula_expression` in `notion:` subtree for provenance

### Deterministic Filename Rule

Files are named using: `sanitize(title) + '—' + pageId.slice(0,8) + '.md'`

- sanitize: NFKD, strip diacritics, `[^\w\- ] → -`, collapse spaces → `-`, lowercase, max 120 chars
- Store a `redirect` note if filename changes (title edit)

## Incremental Sync

The importer supports incremental synchronization:

- Only processes changed pages and databases
- Maintains state in `.obsidian/notion-import.json`
- Creates redirect notes when pages are renamed
- Handles file attachments efficiently

## Architecture

The importer consists of several modular components:

### Core Components

- **NotionClient**: Handles API communication with rate limiting and error handling
- **MarkdownConverter**: Converts Notion blocks and properties to Markdown
- **AttachmentHandler**: Downloads and manages file attachments
- **BaseGenerator**: Creates `.base` files for Obsidian database integration
- **SyncManager**: Manages incremental sync state and operations
- **RelationPatcher**: Resolves Notion relations to Obsidian wikilinks

### Data Flow

1. **Discovery**: Find all accessible databases and data sources
2. **Schema Processing**: Create `.base` files for each data source
3. **Content Processing**: Convert pages to Markdown with frontmatter
4. **Attachment Handling**: Download and relink file attachments
5. **Relation Patching**: Resolve relations to wikilinks in a second pass
6. **State Management**: Update sync state for incremental updates

## Error Handling

The importer includes comprehensive error handling:

- **Rate Limiting**: Automatic backoff on 429 responses
- **Network Errors**: Retry logic with exponential backoff
- **Partial Failures**: Continue processing other items if one fails
- **State Recovery**: Maintains sync state even if import is interrupted

## Customization

### Custom Property Mapping

You can extend the `MarkdownConverter.property_to_frontmatter_value()` method to customize how specific property types are handled.

### Custom Block Rendering

Extend the `MarkdownConverter.block_to_markdown()` method to add support for additional Notion block types.

### Custom Filename Generation

Modify the `MarkdownConverter.generate_filename()` method to change how filenames are generated.

## Troubleshooting

### Common Issues

1. **API Key Issues**
   - Ensure your integration has access to the databases you want to import
   - Check that the API key is correctly set in the `.env` file

2. **Rate Limiting**
   - The importer automatically handles rate limits with backoff
   - Large imports may take time due to API rate limits

3. **Missing Pages**
   - Ensure your integration has been shared with all relevant databases
   - Check the Notion integration settings

4. **Attachment Download Failures**
   - Some attachments may have expired URLs
   - The importer will continue with other attachments if some fail

### Debug Mode

Set environment variable `DEBUG=1` for verbose logging:

```bash
DEBUG=1 python notion_importer.py
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Built for the Notion API version 2025-09-03
- Designed for seamless Obsidian integration
- Inspired by the need for reliable Notion-to-Obsidian migration

