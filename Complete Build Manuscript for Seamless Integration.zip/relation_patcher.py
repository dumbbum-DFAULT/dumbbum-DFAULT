"""
Relation Patcher for resolving Notion relations to Obsidian wikilinks.
"""

import os
import re
import yaml
from typing import Dict, List, Any, Optional


class RelationPatcher:
    """Patches relation placeholders with actual wikilinks."""
    
    def __init__(self, output_dir: str):
        """
        Initialize the relation patcher.
        
        Args:
            output_dir: Base output directory for the import
        """
        self.output_dir = output_dir
        self.page_id_to_filename = {}  # page_id -> filename mapping
        self.page_id_to_title = {}     # page_id -> title mapping
    
    def build_page_mapping(self, sync_manager):
        """
        Build mapping of page IDs to filenames and titles.
        
        Args:
            sync_manager: SyncManager instance
        """
        self.page_id_to_filename = sync_manager.get_all_page_filenames()
        
        # Build title mapping from state
        for page_id, info in sync_manager.state["pages"].items():
            if "title" in info:
                self.page_id_to_title[page_id] = info["title"]
    
    def resolve_relation_ids(self, relation_ids: List[str]) -> List[str]:
        """
        Resolve relation page IDs to wikilinks.
        
        Args:
            relation_ids: List of Notion page IDs
            
        Returns:
            List of wikilinks
        """
        wikilinks = []
        
        for page_id in relation_ids:
            # Clean page ID (remove hyphens)
            clean_id = page_id.replace('-', '')
            
            # Try to find the page
            filename = self.page_id_to_filename.get(page_id)
            title = self.page_id_to_title.get(page_id)
            
            if filename:
                # Use the filename without extension as the link
                link_name = os.path.splitext(filename)[0]
                wikilinks.append(f"[[{link_name}]]")
            elif title:
                # Use the title if we have it
                wikilinks.append(f"[[{title}]]")
            else:
                # Fallback to page ID
                wikilinks.append(f"[[{clean_id}]]")
        
        return wikilinks
    
    def patch_frontmatter_relations(self, frontmatter: Dict[str, Any], 
                                  data_source_properties: Dict[str, Any]) -> Dict[str, Any]:
        """
        Patch relation properties in frontmatter.
        
        Args:
            frontmatter: Page frontmatter
            data_source_properties: Data source property definitions
            
        Returns:
            Updated frontmatter
        """
        updated_frontmatter = frontmatter.copy()
        
        for prop_name, prop_config in data_source_properties.items():
            if prop_config.get("type") == "relation" and prop_name in frontmatter:
                relation_value = frontmatter[prop_name]
                
                # Handle different relation value formats
                if isinstance(relation_value, list):
                    # Extract page IDs from relation objects
                    page_ids = []
                    for item in relation_value:
                        if isinstance(item, dict) and "id" in item:
                            page_ids.append(item["id"])
                        elif isinstance(item, str):
                            page_ids.append(item)
                    
                    # Resolve to wikilinks
                    wikilinks = self.resolve_relation_ids(page_ids)
                    updated_frontmatter[prop_name] = wikilinks
        
        return updated_frontmatter
    
    def patch_markdown_file(self, filepath: str, data_source_properties: Dict[str, Any]):
        """
        Patch relations in a markdown file.
        
        Args:
            filepath: Path to the markdown file
            data_source_properties: Data source property definitions
        """
        if not os.path.exists(filepath):
            return
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Split frontmatter and content
            if content.startswith('---\n'):
                parts = content.split('---\n', 2)
                if len(parts) >= 3:
                    frontmatter_yaml = parts[1]
                    body_content = parts[2]
                    
                    # Parse frontmatter
                    frontmatter = yaml.safe_load(frontmatter_yaml)
                    if frontmatter:
                        # Patch relations
                        updated_frontmatter = self.patch_frontmatter_relations(
                            frontmatter, data_source_properties
                        )
                        
                        # Regenerate content
                        updated_yaml = yaml.dump(updated_frontmatter, 
                                               default_flow_style=False, 
                                               allow_unicode=True)
                        updated_content = f"---\n{updated_yaml}---\n{body_content}"
                        
                        # Write back to file
                        with open(filepath, 'w', encoding='utf-8') as f:
                            f.write(updated_content)
        
        except Exception as e:
            print(f"Warning: Could not patch relations in {filepath}: {e}")
    
    def patch_all_relations(self, data_sources: List[Dict[str, Any]], sync_manager):
        """
        Patch all relation properties in all markdown files.
        
        Args:
            data_sources: List of data source objects
            sync_manager: SyncManager instance
        """
        # Build page mapping
        self.build_page_mapping(sync_manager)
        
        # Process each data source
        for data_source in data_sources:
            data_source_id = data_source.get("id", "")
            properties = data_source.get("properties", {})
            
            # Find all pages for this data source
            for page_id, page_info in sync_manager.state["pages"].items():
                filename = page_info.get("filename")
                if filename:
                    filepath = os.path.join(self.output_dir, filename)
                    self.patch_markdown_file(filepath, properties)
        
        print(f"Patched relations for {len(self.page_id_to_filename)} pages")
    
    def extract_relation_ids_from_page(self, page: Dict[str, Any], 
                                     data_source_properties: Dict[str, Any]) -> Dict[str, List[str]]:
        """
        Extract relation IDs from a page for building the mapping.
        
        Args:
            page: Notion page object
            data_source_properties: Data source property definitions
            
        Returns:
            Dictionary mapping property names to lists of related page IDs
        """
        relations = {}
        properties = page.get("properties", {})
        
        for prop_name, prop_config in data_source_properties.items():
            if prop_config.get("type") == "relation" and prop_name in properties:
                prop_value = properties[prop_name]
                relation_data = prop_value.get("relation", [])
                
                if isinstance(relation_data, list):
                    page_ids = [item.get("id") for item in relation_data 
                               if isinstance(item, dict) and "id" in item]
                    relations[prop_name] = page_ids
        
        return relations

