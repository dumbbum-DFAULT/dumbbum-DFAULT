"""
Markdown Converter for transforming Notion blocks and properties to Obsidian-flavored Markdown.
"""

import re
import unicodedata
from typing import Dict, List, Any, Optional
from datetime import datetime
import yaml


class MarkdownConverter:
    """Converts Notion blocks and properties to Obsidian-flavored Markdown."""
    
    def __init__(self):
        self.attachment_base_path = "attachments"
    
    def sanitize_filename(self, title: str, max_length: int = 120) -> str:
        """
        Sanitize a title for use as a filename.
        
        Args:
            title: Original title
            max_length: Maximum filename length
            
        Returns:
            Sanitized filename
        """
        # Normalize unicode characters
        normalized = unicodedata.normalize('NFKD', title)
        
        # Remove diacritics
        ascii_text = ''.join(c for c in normalized if not unicodedata.combining(c))
        
        # Replace non-word characters with hyphens
        sanitized = re.sub(r'[^\w\- ]', '-', ascii_text)
        
        # Collapse multiple spaces/hyphens
        sanitized = re.sub(r'[-\s]+', '-', sanitized)
        
        # Convert to lowercase and trim
        sanitized = sanitized.lower().strip('-')
        
        # Limit length
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length].rstrip('-')
        
        return sanitized or "untitled"
    
    def generate_filename(self, title: str, page_id: str) -> str:
        """
        Generate a deterministic filename for a page.
        
        Args:
            title: Page title
            page_id: Notion page ID
            
        Returns:
            Filename with .md extension
        """
        sanitized_title = self.sanitize_filename(title)
        short_id = page_id.replace('-', '')[:8]
        return f"{sanitized_title}—{short_id}.md"
    
    def rich_text_to_markdown(self, rich_text: List[Dict[str, Any]]) -> str:
        """
        Convert Notion rich text to Markdown.
        
        Args:
            rich_text: List of rich text objects
            
        Returns:
            Markdown string
        """
        if not rich_text:
            return ""
        
        result = []
        
        for text_obj in rich_text:
            content = text_obj.get("plain_text", "")
            annotations = text_obj.get("annotations", {})
            
            # Apply formatting
            if annotations.get("bold"):
                content = f"**{content}**"
            if annotations.get("italic"):
                content = f"*{content}*"
            if annotations.get("strikethrough"):
                content = f"~~{content}~~"
            if annotations.get("underline"):
                content = f"<u>{content}</u>"
            if annotations.get("code"):
                content = f"`{content}`"
            
            # Handle links
            if text_obj.get("href"):
                content = f"[{content}]({text_obj['href']})"
            
            result.append(content)
        
        return "".join(result)
    
    def block_to_markdown(self, block: Dict[str, Any], level: int = 0) -> str:
        """
        Convert a Notion block to Markdown.
        
        Args:
            block: Notion block object
            level: Nesting level for indentation
            
        Returns:
            Markdown string
        """
        block_type = block.get("type", "")
        block_data = block.get(block_type, {})
        indent = "  " * level
        
        if block_type == "paragraph":
            rich_text = block_data.get("rich_text", [])
            return self.rich_text_to_markdown(rich_text)
        
        elif block_type == "heading_1":
            rich_text = block_data.get("rich_text", [])
            return f"# {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "heading_2":
            rich_text = block_data.get("rich_text", [])
            return f"## {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "heading_3":
            rich_text = block_data.get("rich_text", [])
            return f"### {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "bulleted_list_item":
            rich_text = block_data.get("rich_text", [])
            return f"{indent}- {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "numbered_list_item":
            rich_text = block_data.get("rich_text", [])
            return f"{indent}1. {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "to_do":
            rich_text = block_data.get("rich_text", [])
            checked = block_data.get("checked", False)
            checkbox = "[x]" if checked else "[ ]"
            return f"{indent}- {checkbox} {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "code":
            rich_text = block_data.get("rich_text", [])
            language = block_data.get("language", "")
            code_content = self.rich_text_to_markdown(rich_text)
            return f"```{language}\n{code_content}\n```"
        
        elif block_type == "quote":
            rich_text = block_data.get("rich_text", [])
            return f"> {self.rich_text_to_markdown(rich_text)}"
        
        elif block_type == "callout":
            rich_text = block_data.get("rich_text", [])
            icon = block_data.get("icon", {})
            icon_text = ""
            if icon.get("type") == "emoji":
                icon_text = icon.get("emoji", "")
            
            content = self.rich_text_to_markdown(rich_text)
            return f"> [!note] {icon_text}\n> {content}"
        
        elif block_type == "divider":
            return "---"
        
        elif block_type == "image":
            file_info = block_data.get("file") or block_data.get("external")
            if file_info:
                url = file_info.get("url", "")
                caption = block_data.get("caption", [])
                caption_text = self.rich_text_to_markdown(caption) if caption else ""
                
                # For now, use the original URL. This will be replaced during attachment processing
                alt_text = caption_text or "Image"
                return f"![{alt_text}]({url})"
        
        elif block_type == "table":
            # Tables are complex and would need special handling
            return "<!-- Table content -->"
        
        else:
            # Fallback for unknown block types
            return f"<!-- {block_type} block -->"
        
        return ""
    
    def property_to_frontmatter_value(self, prop_type: str, prop_value: Any, 
                                    prop_config: Dict[str, Any] = None) -> Any:
        """
        Convert a Notion property value to frontmatter format.
        
        Args:
            prop_type: Property type
            prop_value: Property value from Notion
            prop_config: Property configuration (optional)
            
        Returns:
            Frontmatter-compatible value
        """
        if prop_value is None:
            return None
        
        if prop_type == "title":
            if isinstance(prop_value, list) and prop_value:
                return self.rich_text_to_markdown(prop_value)
            return ""
        
        elif prop_type == "rich_text":
            if isinstance(prop_value, list):
                return self.rich_text_to_markdown(prop_value)
            return ""
        
        elif prop_type == "number":
            return prop_value
        
        elif prop_type == "select":
            if prop_value and isinstance(prop_value, dict):
                return prop_value.get("name", "")
            return ""
        
        elif prop_type == "multi_select":
            if isinstance(prop_value, list):
                return [item.get("name", "") for item in prop_value if isinstance(item, dict)]
            return []
        
        elif prop_type == "status":
            if prop_value and isinstance(prop_value, dict):
                return prop_value.get("name", "")
            return ""
        
        elif prop_type == "date":
            if prop_value and isinstance(prop_value, dict):
                start = prop_value.get("start")
                end = prop_value.get("end")
                timezone = prop_value.get("time_zone")
                
                if start:
                    if end:
                        return f"{start} to {end}"
                    return start
            return None
        
        elif prop_type == "checkbox":
            return bool(prop_value)
        
        elif prop_type in ["url", "email", "phone_number"]:
            return str(prop_value) if prop_value else ""
        
        elif prop_type == "people":
            if isinstance(prop_value, list):
                return [person.get("name", person.get("email", "")) 
                       for person in prop_value if isinstance(person, dict)]
            return []
        
        elif prop_type == "files":
            if isinstance(prop_value, list):
                # Return file paths (will be updated during attachment processing)
                return [file_obj.get("name", "") for file_obj in prop_value 
                       if isinstance(file_obj, dict)]
            return []
        
        elif prop_type == "relation":
            # Return placeholder for now, will be patched later
            return []
        
        elif prop_type == "rollup":
            # Return snapshot value based on rollup type
            rollup_type = prop_value.get("type") if isinstance(prop_value, dict) else None
            if rollup_type == "number":
                return prop_value.get("number")
            elif rollup_type == "array":
                return len(prop_value.get("array", []))
            elif rollup_type == "date":
                return prop_value.get("date", {}).get("start")
            return prop_value
        
        elif prop_type == "formula":
            # Return snapshot value based on formula result type
            formula_type = prop_value.get("type") if isinstance(prop_value, dict) else None
            if formula_type == "string":
                return prop_value.get("string", "")
            elif formula_type == "number":
                return prop_value.get("number")
            elif formula_type == "boolean":
                return prop_value.get("boolean")
            elif formula_type == "date":
                date_obj = prop_value.get("date")
                if date_obj:
                    return date_obj.get("start")
            return prop_value
        
        elif prop_type in ["created_time", "last_edited_time"]:
            return prop_value
        
        elif prop_type in ["created_by", "last_edited_by"]:
            if isinstance(prop_value, dict):
                return prop_value.get("name", prop_value.get("email", ""))
            return ""
        
        elif prop_type == "unique_id":
            if isinstance(prop_value, dict):
                prefix = prop_value.get("prefix", "")
                number = prop_value.get("number", "")
                return f"{prefix}{number}"
            return ""
        
        return prop_value
    
    def generate_frontmatter(self, page: Dict[str, Any], data_source: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate frontmatter for a page based on its properties.
        
        Args:
            page: Notion page object
            data_source: Data source schema
            
        Returns:
            Frontmatter dictionary
        """
        frontmatter = {}
        properties = page.get("properties", {})
        data_source_properties = data_source.get("properties", {})
        
        # Add basic metadata
        frontmatter["notion_id"] = page.get("id", "")
        frontmatter["created_time"] = page.get("created_time", "")
        frontmatter["last_edited_time"] = page.get("last_edited_time", "")
        
        # Process each property
        for prop_name, prop_value in properties.items():
            if prop_name in data_source_properties:
                prop_config = data_source_properties[prop_name]
                prop_type = prop_config.get("type", "")
                
                # Get the actual value based on property type
                actual_value = prop_value.get(prop_type) if isinstance(prop_value, dict) else prop_value
                
                # Convert to frontmatter format
                fm_value = self.property_to_frontmatter_value(prop_type, actual_value, prop_config)
                
                if fm_value is not None:
                    frontmatter[prop_name] = fm_value
                
                # Store formula expression for provenance
                if prop_type == "formula" and prop_config.get("formula", {}).get("expression"):
                    if "notion" not in frontmatter:
                        frontmatter["notion"] = {}
                    frontmatter["notion"][f"{prop_name}_formula_expression"] = prop_config["formula"]["expression"]
        
        return frontmatter
    
    def page_to_markdown(self, page: Dict[str, Any], blocks: List[Dict[str, Any]], 
                        data_source: Dict[str, Any]) -> str:
        """
        Convert a Notion page to Markdown with frontmatter.
        
        Args:
            page: Notion page object
            blocks: List of page blocks
            data_source: Data source schema
            
        Returns:
            Complete Markdown content
        """
        # Generate frontmatter
        frontmatter = self.generate_frontmatter(page, data_source)
        
        # Convert blocks to markdown
        content_lines = []
        for block in blocks:
            markdown_line = self.block_to_markdown(block)
            if markdown_line:
                content_lines.append(markdown_line)
        
        content = "\n\n".join(content_lines)
        
        # Combine frontmatter and content
        yaml_frontmatter = yaml.dump(frontmatter, default_flow_style=False, allow_unicode=True)
        
        return f"---\n{yaml_frontmatter}---\n\n{content}"

