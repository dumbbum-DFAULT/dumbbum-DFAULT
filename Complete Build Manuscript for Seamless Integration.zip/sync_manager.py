"""
Sync Manager for handling incremental synchronization and state management.
"""

import json
import os
from typing import Dict, List, Any, Optional
from datetime import datetime


class SyncManager:
    """Manages incremental synchronization state and operations."""
    
    def __init__(self, output_dir: str):
        """
        Initialize the sync manager.
        
        Args:
            output_dir: Base output directory for the import
        """
        self.output_dir = output_dir
        self.obsidian_dir = os.path.join(output_dir, ".obsidian")
        self.state_file = os.path.join(self.obsidian_dir, "notion-import.json")
        self.state = self.load_state()
        
        # Create .obsidian directory if it doesn't exist
        os.makedirs(self.obsidian_dir, exist_ok=True)
    
    def load_state(self) -> Dict[str, Any]:
        """
        Load the synchronization state from file.
        
        Returns:
            State dictionary
        """
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Warning: Could not load state file: {e}")
        
        # Return default state
        return {
            "last_sync": None,
            "pages": {},  # page_id -> {filename, last_edited_time, title}
            "data_sources": {},  # data_source_id -> {filename, last_edited_time, title}
            "databases": {},  # database_id -> {last_edited_time, title}
            "version": "1.0"
        }
    
    def save_state(self):
        """Save the current state to file."""
        try:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(self.state, f, indent=2, ensure_ascii=False)
        except IOError as e:
            print(f"Warning: Could not save state file: {e}")
    
    def should_update_page(self, page_id: str, last_edited_time: str) -> bool:
        """
        Check if a page should be updated based on its last edited time.
        
        Args:
            page_id: Notion page ID
            last_edited_time: Page's last edited time from Notion
            
        Returns:
            True if the page should be updated
        """
        if page_id not in self.state["pages"]:
            return True
        
        stored_time = self.state["pages"][page_id].get("last_edited_time")
        if not stored_time:
            return True
        
        return last_edited_time > stored_time
    
    def should_update_data_source(self, data_source_id: str, last_edited_time: str) -> bool:
        """
        Check if a data source should be updated based on its last edited time.
        
        Args:
            data_source_id: Notion data source ID
            last_edited_time: Data source's last edited time from Notion
            
        Returns:
            True if the data source should be updated
        """
        if data_source_id not in self.state["data_sources"]:
            return True
        
        stored_time = self.state["data_sources"][data_source_id].get("last_edited_time")
        if not stored_time:
            return True
        
        return last_edited_time > stored_time
    
    def update_page_state(self, page_id: str, filename: str, last_edited_time: str, title: str):
        """
        Update the state for a page.
        
        Args:
            page_id: Notion page ID
            filename: Local filename
            last_edited_time: Page's last edited time
            title: Page title
        """
        # Check if filename changed (title change)
        old_entry = self.state["pages"].get(page_id, {})
        old_filename = old_entry.get("filename")
        
        if old_filename and old_filename != filename:
            # Create redirect note
            self.create_redirect_note(old_filename, filename)
        
        self.state["pages"][page_id] = {
            "filename": filename,
            "last_edited_time": last_edited_time,
            "title": title
        }
    
    def update_data_source_state(self, data_source_id: str, filename: str, 
                                last_edited_time: str, title: str):
        """
        Update the state for a data source.
        
        Args:
            data_source_id: Notion data source ID
            filename: Local filename
            last_edited_time: Data source's last edited time
            title: Data source title
        """
        self.state["data_sources"][data_source_id] = {
            "filename": filename,
            "last_edited_time": last_edited_time,
            "title": title
        }
    
    def update_database_state(self, database_id: str, last_edited_time: str, title: str):
        """
        Update the state for a database.
        
        Args:
            database_id: Notion database ID
            last_edited_time: Database's last edited time
            title: Database title
        """
        self.state["databases"][database_id] = {
            "last_edited_time": last_edited_time,
            "title": title
        }
    
    def create_redirect_note(self, old_filename: str, new_filename: str):
        """
        Create a redirect note when a page is renamed.
        
        Args:
            old_filename: Old filename
            new_filename: New filename
        """
        old_path = os.path.join(self.output_dir, old_filename)
        
        # Only create redirect if old file exists
        if os.path.exists(old_path):
            redirect_content = f"""---
redirect_to: "{new_filename}"
---

# Redirect Notice

This page has been moved to [[{new_filename.replace('.md', '')}]].

The content is now available at the new location.
"""
            
            try:
                with open(old_path, 'w', encoding='utf-8') as f:
                    f.write(redirect_content)
                print(f"Created redirect from {old_filename} to {new_filename}")
            except IOError as e:
                print(f"Warning: Could not create redirect note: {e}")
    
    def mark_sync_complete(self):
        """Mark the current sync as complete."""
        self.state["last_sync"] = datetime.utcnow().isoformat() + "Z"
        self.save_state()
    
    def get_page_filename(self, page_id: str) -> Optional[str]:
        """
        Get the stored filename for a page.
        
        Args:
            page_id: Notion page ID
            
        Returns:
            Filename if found, None otherwise
        """
        return self.state["pages"].get(page_id, {}).get("filename")
    
    def get_all_page_filenames(self) -> Dict[str, str]:
        """
        Get all page ID to filename mappings.
        
        Returns:
            Dictionary mapping page IDs to filenames
        """
        return {page_id: info["filename"] 
                for page_id, info in self.state["pages"].items() 
                if "filename" in info}
    
    def cleanup_orphaned_files(self):
        """
        Clean up files that are no longer referenced in the state.
        This is a placeholder for future implementation.
        """
        # TODO: Implement cleanup logic for files that are no longer in Notion
        pass
    
    def get_sync_stats(self) -> Dict[str, Any]:
        """
        Get synchronization statistics.
        
        Returns:
            Dictionary with sync statistics
        """
        return {
            "last_sync": self.state.get("last_sync"),
            "total_pages": len(self.state["pages"]),
            "total_data_sources": len(self.state["data_sources"]),
            "total_databases": len(self.state["databases"]),
            "state_file": self.state_file
        }

