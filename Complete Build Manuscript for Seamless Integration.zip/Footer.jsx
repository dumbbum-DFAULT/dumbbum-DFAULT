import { Badge } from '@/components/ui/badge.jsx'
import { Heart, Code, Zap } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-gradient-to-br from-blue-500 to-purple-600">
                <Zap className="h-4 w-4 text-white" />
              </div>
              <h3 className="font-semibold">Notion Importer</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              A complete end-to-end solution for importing Notion databases and pages 
              into Obsidian-flavored Markdown format with seamless integration.
            </p>
          </div>
          
          <div className="space-y-3">
            <h3 className="font-semibold">Features</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 rounded-full bg-primary" />
                Notion API 2025-09-03 Support
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 rounded-full bg-primary" />
                Obsidian-flavored Markdown
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 rounded-full bg-primary" />
                Incremental Synchronization
              </li>
              <li className="flex items-center gap-2">
                <div className="w-1 h-1 rounded-full bg-primary" />
                Attachment Management
              </li>
            </ul>
          </div>
          
          <div className="space-y-3">
            <h3 className="font-semibold">Technical Details</h3>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">Python</Badge>
              <Badge variant="outline">React</Badge>
              <Badge variant="outline">Notion API</Badge>
              <Badge variant="outline">Markdown</Badge>
              <Badge variant="outline">Obsidian</Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              Built with modern technologies for reliable and efficient data migration.
            </p>
          </div>
        </div>
        
        <div className="border-t mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-red-500" />
            <span>for the Notion community</span>
          </div>
          
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <a 
              href="https://github.com/notion-importer" 
              className="hover:text-foreground transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              GitHub
            </a>
            <a 
              href="https://developers.notion.com" 
              className="hover:text-foreground transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              Notion API
            </a>
            <a 
              href="https://obsidian.md" 
              className="hover:text-foreground transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              Obsidian
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}

