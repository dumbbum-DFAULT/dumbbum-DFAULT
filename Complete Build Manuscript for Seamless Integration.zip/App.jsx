import { Header } from './components/Header.jsx'
import { ImportForm } from './components/ImportForm.jsx'
import { FeatureCard } from './components/FeatureCard.jsx'
import { Footer } from './components/Footer.jsx'
import { 
  Database, 
  FileText, 
  Link, 
  Download, 
  RefreshCw, 
  Settings,
  Zap,
  Shield,
  Clock
} from 'lucide-react'
import './App.css'

function App() {
  const features = [
    {
      icon: Database,
      title: "Data Source Support",
      description: "Full support for Notion's new data source architecture with API version 2025-09-03.",
      features: [
        "Multiple data sources per database",
        "Complete schema preservation",
        "Property type mapping",
        "Metadata retention"
      ],
      status: "ready"
    },
    {
      icon: FileText,
      title: "Markdown Conversion",
      description: "Convert Notion pages to Obsidian-flavored Markdown with full formatting support.",
      features: [
        "Rich text formatting",
        "Block types (headings, lists, callouts)",
        "Code blocks with syntax highlighting",
        "Tables and dividers"
      ],
      status: "ready"
    },
    {
      icon: Link,
      title: "Relation Handling",
      description: "Intelligent relation resolution with two-phase processing for accurate wikilinks.",
      features: [
        "Automatic wikilink generation",
        "Cross-reference preservation",
        "Relation type detection",
        "Bidirectional linking"
      ],
      status: "ready"
    },
    {
      icon: Download,
      title: "Attachment Management",
      description: "Download and organize all file attachments with smart deduplication.",
      features: [
        "Automatic file downloading",
        "Hash-based deduplication",
        "Image embedding",
        "File linking"
      ],
      status: "ready"
    },
    {
      icon: RefreshCw,
      title: "Incremental Sync",
      description: "Smart synchronization that only updates changed content for efficient imports.",
      features: [
        "Change detection",
        "State management",
        "Redirect handling",
        "Conflict resolution"
      ],
      status: "ready"
    },
    {
      icon: Settings,
      title: "Base File Generation",
      description: "Generate Obsidian .base files for seamless database integration.",
      features: [
        "Schema mapping",
        "View configuration",
        "Property preservation",
        "Metadata hints"
      ],
      status: "ready"
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="text-center py-12 space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600">
                <Zap className="h-8 w-8 text-white" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Seamless Migration
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Transform your Notion workspace into Obsidian-ready Markdown files with complete 
              data integrity and intelligent relation mapping.
            </p>
          </div>
          
          <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-green-500" />
              <span>API v2025-09-03</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-500" />
              <span>Incremental Sync</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-purple-500" />
              <span>Zero Data Loss</span>
            </div>
          </div>
        </section>

        {/* Import Form Section */}
        <section className="py-8">
          <ImportForm />
        </section>

        {/* Features Section */}
        <section className="py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight mb-4">
              Comprehensive Feature Set
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Built with modern architecture and best practices to ensure reliable, 
              efficient, and complete data migration from Notion to Obsidian.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <FeatureCard key={index} {...feature} />
            ))}
          </div>
        </section>

        {/* Technical Details Section */}
        <section className="py-16 bg-muted/30 rounded-2xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight mb-4">
              Technical Excellence
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Built on solid foundations with comprehensive error handling, 
              rate limiting, and modular architecture.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div className="space-y-3">
              <div className="text-3xl font-bold text-primary">100%</div>
              <div className="text-sm font-medium">Data Integrity</div>
              <div className="text-xs text-muted-foreground">
                Complete preservation of all content and metadata
              </div>
            </div>
            <div className="space-y-3">
              <div className="text-3xl font-bold text-primary">2-Phase</div>
              <div className="text-sm font-medium">Relation Processing</div>
              <div className="text-xs text-muted-foreground">
                Intelligent resolution of cross-references
              </div>
            </div>
            <div className="space-y-3">
              <div className="text-3xl font-bold text-primary">Auto</div>
              <div className="text-sm font-medium">Rate Limiting</div>
              <div className="text-xs text-muted-foreground">
                Built-in backoff and retry mechanisms
              </div>
            </div>
            <div className="space-y-3">
              <div className="text-3xl font-bold text-primary">∞</div>
              <div className="text-sm font-medium">Scalability</div>
              <div className="text-xs text-muted-foreground">
                Handles workspaces of any size efficiently
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

export default App
