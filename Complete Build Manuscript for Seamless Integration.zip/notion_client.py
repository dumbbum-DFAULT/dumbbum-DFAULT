"""
Notion API Client for interacting with Notion's API version 2025-09-03.
Handles data sources, databases, and pages with proper error handling and rate limiting.
"""

import requests
import time
import json
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin


class NotionAPIError(Exception):
    """Custom exception for Notion API errors."""
    pass


class NotionClient:
    """Client for interacting with Notion API version 2025-09-03."""
    
    def __init__(self, api_key: str, api_version: str = "2025-09-03"):
        """
        Initialize the Notion client.
        
        Args:
            api_key: Notion integration API key
            api_version: API version to use (default: 2025-09-03)
        """
        self.api_key = api_key
        self.api_version = api_version
        self.base_url = "https://api.notion.com/v1/"
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Notion-Version": api_version,
            "Content-Type": "application/json"
        })
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """
        Make a request to the Notion API with error handling and rate limiting.
        
        Args:
            method: HTTP method (GET, POST, PATCH, etc.)
            endpoint: API endpoint (relative to base URL)
            **kwargs: Additional arguments for requests
            
        Returns:
            JSON response as dictionary
            
        Raises:
            NotionAPIError: If the API request fails
        """
        url = urljoin(self.base_url, endpoint)
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                response = self.session.request(method, url, **kwargs)
                
                # Handle rate limiting (429)
                if response.status_code == 429:
                    retry_after = int(response.headers.get('Retry-After', retry_delay))
                    print(f"Rate limited. Waiting {retry_after} seconds...")
                    time.sleep(retry_after)
                    retry_delay *= 2  # Exponential backoff
                    continue
                
                # Check for other errors
                if not response.ok:
                    error_data = response.json() if response.content else {}
                    raise NotionAPIError(
                        f"API request failed: {response.status_code} - {error_data.get('message', 'Unknown error')}"
                    )
                
                return response.json()
                
            except requests.RequestException as e:
                if attempt == max_retries - 1:
                    raise NotionAPIError(f"Request failed after {max_retries} attempts: {str(e)}")
                time.sleep(retry_delay)
                retry_delay *= 2
    
    def search_databases(self, query: str = "", page_size: int = 100) -> List[Dict[str, Any]]:
        """
        Search for databases accessible to the integration.
        
        Args:
            query: Search query (optional)
            page_size: Number of results per page (max 100)
            
        Returns:
            List of database objects
        """
        databases = []
        start_cursor = None
        
        while True:
            params = {
                "filter": {"object": "database"},
                "page_size": page_size
            }
            
            if query:
                params["query"] = query
            
            if start_cursor:
                params["start_cursor"] = start_cursor
            
            response = self._make_request("POST", "search", json=params)
            
            databases.extend(response.get("results", []))
            
            if not response.get("has_more", False):
                break
                
            start_cursor = response.get("next_cursor")
        
        return databases
    
    def get_database(self, database_id: str) -> Dict[str, Any]:
        """
        Retrieve a database by ID.
        
        Args:
            database_id: Database ID
            
        Returns:
            Database object
        """
        return self._make_request("GET", f"databases/{database_id}")
    
    def get_data_source(self, data_source_id: str) -> Dict[str, Any]:
        """
        Retrieve a data source by ID.
        
        Args:
            data_source_id: Data source ID
            
        Returns:
            Data source object
        """
        return self._make_request("GET", f"data_sources/{data_source_id}")
    
    def query_data_source(self, data_source_id: str, page_size: int = 100, 
                         filter_conditions: Optional[Dict] = None,
                         sorts: Optional[List[Dict]] = None) -> List[Dict[str, Any]]:
        """
        Query pages from a data source.
        
        Args:
            data_source_id: Data source ID
            page_size: Number of results per page (max 100)
            filter_conditions: Filter conditions (optional)
            sorts: Sort conditions (optional)
            
        Returns:
            List of page objects
        """
        pages = []
        start_cursor = None
        
        while True:
            params = {
                "page_size": page_size
            }
            
            if filter_conditions:
                params["filter"] = filter_conditions
            
            if sorts:
                params["sorts"] = sorts
            
            if start_cursor:
                params["start_cursor"] = start_cursor
            
            response = self._make_request("POST", f"data_sources/{data_source_id}/query", json=params)
            
            pages.extend(response.get("results", []))
            
            if not response.get("has_more", False):
                break
                
            start_cursor = response.get("next_cursor")
        
        return pages
    
    def get_page(self, page_id: str) -> Dict[str, Any]:
        """
        Retrieve a page by ID.
        
        Args:
            page_id: Page ID
            
        Returns:
            Page object
        """
        return self._make_request("GET", f"pages/{page_id}")
    
    def get_page_blocks(self, page_id: str, page_size: int = 100) -> List[Dict[str, Any]]:
        """
        Retrieve blocks (content) from a page.
        
        Args:
            page_id: Page ID
            page_size: Number of results per page (max 100)
            
        Returns:
            List of block objects
        """
        blocks = []
        start_cursor = None
        
        while True:
            params = {
                "page_size": page_size
            }
            
            if start_cursor:
                params["start_cursor"] = start_cursor
            
            response = self._make_request("GET", f"blocks/{page_id}/children", params=params)
            
            blocks.extend(response.get("results", []))
            
            if not response.get("has_more", False):
                break
                
            start_cursor = response.get("next_cursor")
        
        return blocks
    
    def download_file(self, file_url: str) -> bytes:
        """
        Download a file from Notion.
        
        Args:
            file_url: URL of the file to download
            
        Returns:
            File content as bytes
        """
        response = requests.get(file_url)
        response.raise_for_status()
        return response.content

