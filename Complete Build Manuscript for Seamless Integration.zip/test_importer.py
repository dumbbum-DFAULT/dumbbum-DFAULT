"""
Test script for the Notion Importer.
This script provides basic testing functionality and validation.
"""

import os
import json
import tempfile
import shutil
from typing import Dict, Any
from unittest.mock import Mock, patch

from notion_client import NotionClient
from markdown_converter import MarkdownConverter
from attachment_handler import AttachmentHandler
from base_generator import BaseGenerator
from sync_manager import SyncManager
from relation_patcher import RelationPatcher


class NotionImporterTester:
    """Test suite for the Notion Importer."""
    
    def __init__(self):
        """Initialize the tester."""
        self.test_dir = None
        self.passed_tests = 0
        self.failed_tests = 0
    
    def setup_test_environment(self):
        """Set up a temporary test environment."""
        self.test_dir = tempfile.mkdtemp(prefix="notion_importer_test_")
        print(f"Test environment created: {self.test_dir}")
    
    def cleanup_test_environment(self):
        """Clean up the test environment."""
        if self.test_dir and os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
            print(f"Test environment cleaned up: {self.test_dir}")
    
    def assert_test(self, condition: bool, test_name: str, message: str = ""):
        """Assert a test condition."""
        if condition:
            print(f"✅ PASS: {test_name}")
            self.passed_tests += 1
        else:
            print(f"❌ FAIL: {test_name} - {message}")
            self.failed_tests += 1
    
    def test_markdown_converter(self):
        """Test the MarkdownConverter functionality."""
        print("\n--- Testing MarkdownConverter ---")
        
        converter = MarkdownConverter()
        
        # Test filename sanitization
        test_cases = [
            ("Hello World", "hello-world"),
            ("Test/File\\Name", "test-file-name"),
            ("Spéciál Chàracters", "special-characters"),
            ("", "untitled"),
            ("A" * 150, "a" * 120)  # Length limit
        ]
        
        for input_title, expected in test_cases:
            result = converter.sanitize_filename(input_title)
            self.assert_test(
                result == expected,
                f"Filename sanitization: '{input_title}' -> '{result}'",
                f"Expected '{expected}', got '{result}'"
            )
        
        # Test filename generation
        filename = converter.generate_filename("Test Page", "12345678-1234-1234-1234-123456789012")
        expected_filename = "test-page—12345678.md"
        self.assert_test(
            filename == expected_filename,
            f"Filename generation: {filename}",
            f"Expected '{expected_filename}', got '{filename}'"
        )
        
        # Test rich text conversion
        rich_text = [
            {
                "plain_text": "Hello ",
                "annotations": {"bold": True}
            },
            {
                "plain_text": "World",
                "annotations": {"italic": True}
            }
        ]
        
        result = converter.rich_text_to_markdown(rich_text)
        expected = "**Hello ***World**"
        self.assert_test(
            "Hello" in result and "World" in result,
            f"Rich text conversion: {result}",
            f"Should contain formatted text"
        )
        
        # Test property conversion
        test_property_cases = [
            ("title", [{"plain_text": "Test Title"}], "Test Title"),
            ("number", 42, 42),
            ("checkbox", True, True),
            ("select", {"name": "Option 1"}, "Option 1"),
            ("multi_select", [{"name": "Tag1"}, {"name": "Tag2"}], ["Tag1", "Tag2"])
        ]
        
        for prop_type, prop_value, expected in test_property_cases:
            result = converter.property_to_frontmatter_value(prop_type, prop_value)
            self.assert_test(
                result == expected,
                f"Property conversion {prop_type}: {result}",
                f"Expected {expected}, got {result}"
            )
    
    def test_attachment_handler(self):
        """Test the AttachmentHandler functionality."""
        print("\n--- Testing AttachmentHandler ---")
        
        handler = AttachmentHandler(self.test_dir)
        
        # Test directory creation
        self.assert_test(
            os.path.exists(handler.attachments_dir),
            "Attachments directory creation",
            "Directory should be created"
        )
        
        # Test file hash generation
        test_content = b"Hello, World!"
        file_hash = handler.get_file_hash(test_content)
        expected_hash = "dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f"
        self.assert_test(
            file_hash == expected_hash,
            f"File hash generation: {file_hash}",
            f"Expected {expected_hash}"
        )
        
        # Test file extension detection
        test_cases = [
            ("https://example.com/image.jpg", "image/jpeg", ".jpg"),
            ("https://example.com/document.pdf", "application/pdf", ".pdf"),
            ("https://example.com/file", "text/plain", ".txt"),
            ("https://example.com/unknown", None, ".bin")
        ]
        
        for url, content_type, expected_ext in test_cases:
            result = handler.get_file_extension(url, content_type)
            self.assert_test(
                result == expected_ext,
                f"File extension detection: {url} -> {result}",
                f"Expected {expected_ext}"
            )
    
    def test_base_generator(self):
        """Test the BaseGenerator functionality."""
        print("\n--- Testing BaseGenerator ---")
        
        generator = BaseGenerator()
        
        # Test type mapping
        test_cases = [
            ("title", "string"),
            ("number", "number"),
            ("checkbox", "boolean"),
            ("multi_select", "string[]"),
            ("relation", "string[]")
        ]
        
        for notion_type, expected_base_type in test_cases:
            result = generator.notion_type_to_base_type(notion_type)
            self.assert_test(
                result == expected_base_type,
                f"Type mapping {notion_type} -> {result}",
                f"Expected {expected_base_type}"
            )
        
        # Test base file generation
        mock_data_source = {
            "id": "test-data-source-id",
            "title": [{"plain_text": "Test Data Source"}],
            "properties": {
                "Name": {
                    "type": "title",
                    "title": {}
                },
                "Status": {
                    "type": "select",
                    "select": {
                        "options": [
                            {"name": "Todo", "color": "red"},
                            {"name": "Done", "color": "green"}
                        ]
                    }
                }
            },
            "created_time": "2023-01-01T00:00:00.000Z",
            "last_edited_time": "2023-01-01T00:00:00.000Z"
        }
        
        base_content = generator.generate_base_file(mock_data_source)
        self.assert_test(
            "Test Data Source" in base_content,
            "Base file generation contains title",
            "Should include data source title"
        )
        
        self.assert_test(
            "Name:" in base_content and "Status:" in base_content,
            "Base file generation contains properties",
            "Should include all properties"
        )
        
        filename = generator.generate_base_filename(mock_data_source)
        self.assert_test(
            filename.endswith(".base"),
            f"Base filename generation: {filename}",
            "Should end with .base extension"
        )
    
    def test_sync_manager(self):
        """Test the SyncManager functionality."""
        print("\n--- Testing SyncManager ---")
        
        sync_manager = SyncManager(self.test_dir)
        
        # Test state initialization
        self.assert_test(
            isinstance(sync_manager.state, dict),
            "State initialization",
            "State should be a dictionary"
        )
        
        self.assert_test(
            "pages" in sync_manager.state,
            "State structure",
            "State should contain pages key"
        )
        
        # Test page state updates
        page_id = "test-page-id"
        filename = "test-page.md"
        last_edited = "2023-01-01T00:00:00.000Z"
        title = "Test Page"
        
        sync_manager.update_page_state(page_id, filename, last_edited, title)
        
        self.assert_test(
            page_id in sync_manager.state["pages"],
            "Page state update",
            "Page should be added to state"
        )
        
        stored_info = sync_manager.state["pages"][page_id]
        self.assert_test(
            stored_info["filename"] == filename,
            "Page filename storage",
            f"Expected {filename}, got {stored_info.get('filename')}"
        )
        
        # Test should_update_page logic
        should_update = sync_manager.should_update_page(page_id, "2023-01-02T00:00:00.000Z")
        self.assert_test(
            should_update,
            "Should update page (newer timestamp)",
            "Should return True for newer timestamp"
        )
        
        should_not_update = sync_manager.should_update_page(page_id, "2022-12-31T00:00:00.000Z")
        self.assert_test(
            not should_not_update,
            "Should not update page (older timestamp)",
            "Should return False for older timestamp"
        )
    
    def test_relation_patcher(self):
        """Test the RelationPatcher functionality."""
        print("\n--- Testing RelationPatcher ---")
        
        patcher = RelationPatcher(self.test_dir)
        
        # Test page mapping
        patcher.page_id_to_filename = {
            "page-1": "page-one.md",
            "page-2": "page-two.md"
        }
        patcher.page_id_to_title = {
            "page-1": "Page One",
            "page-2": "Page Two"
        }
        
        # Test relation resolution
        relation_ids = ["page-1", "page-2", "unknown-page"]
        wikilinks = patcher.resolve_relation_ids(relation_ids)
        
        self.assert_test(
            len(wikilinks) == 3,
            f"Relation resolution count: {len(wikilinks)}",
            "Should resolve all relation IDs"
        )
        
        self.assert_test(
            "[[page-one]]" in wikilinks,
            "Relation resolution content",
            "Should contain correct wikilink"
        )
    
    def test_integration(self):
        """Test integration between components."""
        print("\n--- Testing Integration ---")
        
        # Create a mock workflow
        converter = MarkdownConverter()
        sync_manager = SyncManager(self.test_dir)
        
        # Mock page data
        mock_page = {
            "id": "test-page-id",
            "last_edited_time": "2023-01-01T00:00:00.000Z",
            "properties": {
                "Name": {
                    "title": [{"plain_text": "Integration Test Page"}]
                },
                "Status": {
                    "select": {"name": "In Progress"}
                }
            }
        }
        
        mock_data_source = {
            "properties": {
                "Name": {"type": "title"},
                "Status": {"type": "select"}
            }
        }
        
        mock_blocks = [
            {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"plain_text": "This is a test paragraph."}]
                }
            }
        ]
        
        # Test full conversion workflow
        markdown_content = converter.page_to_markdown(mock_page, mock_blocks, mock_data_source)
        
        self.assert_test(
            "Integration Test Page" in markdown_content,
            "Integration: Page title in markdown",
            "Should include page title"
        )
        
        self.assert_test(
            "Status: In Progress" in markdown_content,
            "Integration: Property in frontmatter",
            "Should include property in frontmatter"
        )
        
        self.assert_test(
            "This is a test paragraph" in markdown_content,
            "Integration: Block content in markdown",
            "Should include block content"
        )
        
        # Test filename generation and state update
        title = "Integration Test Page"
        filename = converter.generate_filename(title, mock_page["id"])
        sync_manager.update_page_state(
            mock_page["id"], 
            filename, 
            mock_page["last_edited_time"], 
            title
        )
        
        retrieved_filename = sync_manager.get_page_filename(mock_page["id"])
        self.assert_test(
            retrieved_filename == filename,
            "Integration: State management",
            f"Expected {filename}, got {retrieved_filename}"
        )
    
    def run_all_tests(self):
        """Run all tests."""
        print("🧪 Starting Notion Importer Tests")
        print("=" * 50)
        
        try:
            self.setup_test_environment()
            
            # Run individual test suites
            self.test_markdown_converter()
            self.test_attachment_handler()
            self.test_base_generator()
            self.test_sync_manager()
            self.test_relation_patcher()
            self.test_integration()
            
            # Print summary
            print("\n" + "=" * 50)
            print("🏁 Test Summary")
            print(f"✅ Passed: {self.passed_tests}")
            print(f"❌ Failed: {self.failed_tests}")
            print(f"📊 Total: {self.passed_tests + self.failed_tests}")
            
            if self.failed_tests == 0:
                print("🎉 All tests passed!")
                return True
            else:
                print("💥 Some tests failed!")
                return False
                
        finally:
            self.cleanup_test_environment()


def main():
    """Main test runner."""
    tester = NotionImporterTester()
    success = tester.run_all_tests()
    
    if not success:
        exit(1)


if __name__ == "__main__":
    main()

